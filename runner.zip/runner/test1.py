import pygame
import random
import os
import sys
from pygame.locals import *
def ooo():
    pygame.init()
    display_width = 1400
    display_height = 900
    gameDisplay = pygame.display.set_mode((display_width,display_height))
    pygame.display.set_caption('RUNNER')
    run=True
    clock=pygame.time.Clock()
    bgx=0
    bgx1=1400
    a=pygame.image.load("back.png").convert()
    b=pygame.transform.scale(a,(1400,900))
    c=pygame.image.load("back.png").convert()
    d=pygame.transform.scale(a,(1400,900))
    e=pygame.image.load("man.jpg").convert()
    f=pygame.transform.scale(e,(70,70))
    g=pygame.image.load("star.png").convert()
    h=pygame.transform.scale(g,(70,70))
    font = pygame.font.Font('freesansbold.ttf', 32)
    y=700
    st=0
    c=0
    x=0
    s=0
    dis=0
    sp=100
    las=0
    la=0
    check=0
    las1=1
    posxl=2
    i=pygame.image.load("miss.jpeg").convert()
    while(run):
        sp+=0.5
        clock.tick(sp)
        if(las1==1):
            las1=0
            size1=random.randint(70,200)
            size2=random.randint(70,200)
            if(posxl<0):
                las1=1
        j=pygame.transform.scale(i,(size1,size2))
        #clock.tick(sp)
        if(bgx>=-1400):
            gameDisplay.blit(b, (bgx,0))
            gameDisplay.blit(d, (bgx1,0))
            bgx-=1.4
            bgx1-=1.4
        else:
            bgx=0
            bgx1=1400
            gameDisplay.blit(b, (bgx,0))
            gameDisplay.blit(d, (bgx1,0))
        
        for event in pygame.event.get():
                if(event.type==pygame.QUIT):
                    run=False
        keys=pygame.key.get_pressed()
        if(keys[pygame.K_UP]):
            if(y>=200):
                y-=4
            gameDisplay.blit(f, (x,y))
        else:
            gameDisplay.blit(f, (x,y))
            if(y!=700):
                y+=4
            else:
                y=700
        if(keys[pygame.K_RIGHT]):
            if(x<=1400):
                x+=4
            gameDisplay.blit(f, (x,y))
        if(keys[pygame.K_LEFT]):
            if(x>=0):
                x-=4
            gameDisplay.blit(f, (x,y))
        
        if(c!=1):
            posx=random.randint(0,1400)
            posy=random.randint(200,700)
        if(las!=1):
            #posxl=random.randint(0,1400)
            posxl=1400
            posyl=random.randint(200,700)
        if(st==1):
            c=1
            gameDisplay.blit(h, (posx,posy))
            posx-=1.4
            if(posx-35<=x<=posx+35 and posy-35<=y<=posy+35):
                c=0
                st=0
                s+=1
            if(posx<0):
                c=0
                st=0
        else:
            st=random.randint(0,1000)
        ran=random.randint(3,5)
        
        if(la==23 or la==45 or la==89 or las==1):
            las=1
            #las1=1
            gameDisplay.blit(j, (posxl,posyl))
            posxl-=ran
            if(posxl<0):
                las=0
                la=0
            if(posxl-(size1/2)<=x<=posxl+(size2/2) and posyl-(size1/2)<=y<=posyl+(size2/2)):
                run=False
                check=1
            #la=random.randint(0,100)

        else:
            la=random.randint(0,100)
            las=0
            las1=1
        sco = font.render("DISTANCE:"+str(dis), True, (0,0,0), (255,255,255))
        textRectsco = sco.get_rect()
        textRectsco.center = (600,100)
        gameDisplay.blit(sco, textRectsco)
        star = font.render("STARS:"+str(s), True, (0,0,0), (255,255,255))
        textRectst = star.get_rect()
        textRectst.center = (1000,100)
        gameDisplay.blit(star, textRectst)
        dis+=0.01
        #sp+=0.5
        pygame.display.update()
    if(check==1):
        run=True
        while(run):
            gameDisplay.blit(sco, textRectsco)
            gameDisplay.blit(star, textRectst)
            for event in pygame.event.get():
                if(event.type==pygame.QUIT):
                    run=False
            keys=pygame.key.get_pressed()
            if(keys[pygame.K_r]):
                ooo()
ooo()

    
